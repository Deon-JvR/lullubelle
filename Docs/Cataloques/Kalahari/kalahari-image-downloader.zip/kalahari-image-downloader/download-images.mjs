
import fs from "node:fs/promises";
import path from "node:path";
import sharp from "sharp";

const PRODUCTS_URL = "https://skin-c.co.za/collections/kalahari/products.json?limit=250";
const outputDir = path.resolve("public/images/products/kalahari");
const wanted = JSON.parse(await fs.readFile("products.json", "utf8"));

const aliases = new Map([
  ["facial cleanser", ["facial cleansing gel"]],
  ["skincare journey kit in travel bag", ["intro kit"]],
  ["solar defence fluid 50", ["solar defence fluid spf 50"]],
  ["gentle cleansing milk", ["gentle cleansing milk 160ml"]],
  ["phyto fluid foundation honey", ["phyto fluid foundation | honey"]],
  ["nourishing face and neck mask", ["nourishing face & neck mask"]],
  ["ferulic ceb+ serum", ["ferulic ceb + serum"]],
  ["phyto-correct serum", ["phyto-correct serum"]],
  ["she butter lip balm - rose round", ["shea butter lip balm"]],
]);

function normalize(value) {
  return String(value)
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/\+/g, " plus ")
    .replace(/\b(spf|ph)\s*/g, "$1 ")
    .replace(/\b\d+\s*(ml|g|pc|pcs|unit|units)\b/g, " ")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\b(with|and|the|in|tube|set)\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tokens(value) {
  return new Set(normalize(value).split(" ").filter(Boolean));
}

function score(a, b) {
  const A = tokens(a), B = tokens(b);
  if (!A.size || !B.size) return 0;
  let intersection = 0;
  for (const t of A) if (B.has(t)) intersection++;
  return (2 * intersection) / (A.size + B.size);
}

async function fetchJson(url) {
  const response = await fetch(url, {
    headers: {"user-agent": "Mozilla/5.0 Lullubelle authorized stockist image importer"}
  });
  if (!response.ok) throw new Error(`${response.status} ${response.statusText}: ${url}`);
  return response.json();
}

async function downloadBuffer(url) {
  const response = await fetch(url, {
    headers: {"user-agent": "Mozilla/5.0 Lullubelle authorized stockist image importer"}
  });
  if (!response.ok) throw new Error(`${response.status} ${response.statusText}: ${url}`);
  return Buffer.from(await response.arrayBuffer());
}

await fs.mkdir(outputDir, {recursive: true});
const catalogue = await fetchJson(PRODUCTS_URL);
const sourceProducts = catalogue.products ?? [];
const report = [];

for (const item of wanted) {
  const requested = item.name;
  const candidates = [requested, ...(aliases.get(normalize(requested)) ?? [])];

  let best = null;
  for (const source of sourceProducts) {
    const title = source.title ?? "";
    const currentScore = Math.max(...candidates.map(c => score(c, title)));
    if (!best || currentScore > best.score) best = {source, score: currentScore};
  }

  if (!best || best.score < 0.48 || !best.source.images?.[0]?.src) {
    report.push({...item, status: "missing", bestMatch: best?.source?.title ?? "", score: best?.score ?? 0});
    console.warn(`MISSING  ${item.sku} ${item.name} — best: ${best?.source?.title ?? "none"} (${(best?.score ?? 0).toFixed(2)})`);
    continue;
  }

  const imageUrl = best.source.images[0].src.replace(/^\/\//, "https://");
  const buffer = await downloadBuffer(imageUrl);
  const filename = `${item.sku.toLowerCase()}.webp`;
  const destination = path.join(outputDir, filename);

  await sharp(buffer)
    .resize(1200, 1200, {
      fit: "contain",
      background: {r: 255, g: 255, b: 255, alpha: 1},
      withoutEnlargement: true,
    })
    .webp({quality: 88})
    .toFile(destination);

  report.push({
    ...item,
    status: "downloaded",
    matchedProduct: best.source.title,
    score: Number(best.score.toFixed(3)),
    imageUrl,
    filename,
  });
  console.log(`OK       ${item.sku} ${item.name} <- ${best.source.title}`);
}

await fs.writeFile(
  path.resolve("kalahari-image-download-report.json"),
  JSON.stringify(report, null, 2)
);

const downloaded = report.filter(r => r.status === "downloaded").length;
const missing = report.length - downloaded;
console.log(`\nFinished: ${downloaded} downloaded, ${missing} requiring manual review.`);
if (missing) process.exitCode = 2;
