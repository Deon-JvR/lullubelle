# Kalahari product image downloader

This package downloads the official Kalahari product images needed for the products in the supplied 2025 price list.

## Run inside the Lullubelle repository

1. Copy this folder into the repository root.
2. Open Terminal in this folder.
3. Run:

```bash
npm install
npm run download
```

Images are saved to:

```text
public/images/products/kalahari/
```

Each image is converted to a consistent 1200 × 1200 WebP file and named by SKU, for example:

```text
cle01.webp
fk2090.webp
es01.webp
```

A matching report is created as `kalahari-image-download-report.json`.

Review every image before publishing. Products that cannot be matched confidently are marked `missing` rather than receiving an incorrect image.
